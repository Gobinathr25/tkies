import { Component, OnInit, ViewChild } from '@angular/core';
import { HotelService } from '../services/hotel.service';
import { HotelComponent } from '../hotel/hotel.component';
import { ActivatedRoute, Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'hoteldetail',
  templateUrl: './hoteldetail.component.html',
  styleUrls: ['./hoteldetail.component.scss'],
})


export class HoteldetailComponent implements OnInit {

  hotelDetails={};
  reqObj = {};
  images: Array<any>;
  
constructor(private hotelService: HotelService, private activatedRoute: ActivatedRoute, private router: Router){
  const navigation = this.router.getCurrentNavigation();
  const state = navigation.extras.state as {
    api: string;
    trace_id: string;
    token_id: string;
    hotel_code: string;
    result_index: string;
  };
this.reqObj = {
api: state.api,
trace_id: state.trace_id,
token_id: state.token_id,
hotel_code: state.hotel_code,
result_index: state.result_index
};
  console.log(this.reqObj);

  this.hotelService.getHotelDetail(this.reqObj).subscribe(
    (hotelDetail) => {
      this.hotelDetails = hotelDetail.tbohotel;
      console.log("hotel:", this.hotelDetails);
    },
    (err) => console.log(err));
}

  ngOnInit() {
     
}
}

