/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function doMenuDropdownAction(idString) {

    var divBody = document.getElementById(idString + 'Body');
    var arrow = document.getElementById(idString + 'Arrow');
	 

    if (divBody.style.display === "none") {
        divBody.style.display = "block";
		
        arrow.classList.remove("fa-angle-down");
        arrow.classList.add("fa-angle-up");
    } else {
        divBody.style.display = "none";
        arrow.classList.remove("fa-angle-up");
        arrow.classList.add("fa-angle-down");
		
    }
}
  $(document).ready(function () {
	   (function ($) {
    var hide = true;
  $(document).on("click", function () {
      if (hide) $('.ratings label').removeClass('selected');
      hide = true;
  });
  
  // add and remove .active
  $(document).on('click', '.ratings label', function (g) {
  
      var self = $(this);
  
      if (self.hasClass('selected')) {
          $('.ratings label').removeClass('selected');
          return false;
      }
  
      $('.ratings label').removeClass('selected');
  
      self.toggleClass('selected');
      hide = false;
  g.preventDefault();
    });
	  })(jQuery);
	 });
	 
	 
		  
		  
    $(document).ready(function () {
  function doMenuDropdownAction(idString) {
  
      var divBody = document.getElementById(idString + 'Body');
      var arrow = document.getElementById(idString + 'Arrow');
     
  
      if (divBody.style.display === "none") {
          divBody.style.display = "block";
      
          arrow.classList.remove("fa-caret-down");
          arrow.classList.add("fa-caret-up");
      } else {
          divBody.style.display = "none";
          arrow.classList.remove("fa-caret-up");
          arrow.classList.add("fa-caret-down");
      
      }
  }
}); 

