/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var RoomAddBool = true;
var maxroom = 3;
var roomID = 2;

$(function(){
	 $(document).on( "click", ".custombtn", function(e) {

        var rmid = 0;
       
        $(".user-details").find(".user_data").each(function () {
			
            num = parseInt(this.id.substring(7, 8));
			
            if (num > rmid) {
                rmid = num;
            }
        });
        if (rmid < maxroom) {
           //alert(rmid);
            var rmindx = parseInt(rmid) + 1;
			
            if (RoomAddBool == true) {
                RoomAddBool = false;
			var room = "<div id='divRoom" + rmindx + "' class='form-row user_data hidedone'>" + 
										  "<div class='col-md-1 col-3 roomdiv'>Room " + rmindx + "</div>" +
										  
                                           " <div class='col-md-2 col-4  font-sm-three'>" +
                                                "<label class='label-form-card' for='validationCustom01'>Adults(>11 Yrs)</label>" +
                                               


                                               "<div class='quantity'> " +
                                                    
													 "<input id='room" + rmindx + "AdultMinus' class='quantity__minus adult_minus' type='button' value='-' style='color:#ffffff;'>" +
                                                   " <input  type='text' class=' quantity__input adult_input' value='1' data-val='true' data-val-number='The field NoOfAdults must be a number.' data-val-required='The NoOfAdults field is required.' id='room" + rmindx + "Adult' name='roomsNoOfAdults[]' >" +
                                                    
													"<input id='room" + rmindx + "AdultPlus' class='quantity__plus adult_plus' type='button' value='+' style='color:#ffffff;'>" +
                                               " </div>"+
												 "<label id='room" + rmindx + "Adult-error' class='error' style='display:none;' for='room" + rmindx + "Adult'>Please enter a value greater than or equal to 1.</label>"+																																									  




                                           " </div>"+
                                            "<div class='col-md-2 col-4 font-sm-three ' style='white-space:nowrap'>"+
                                                "<label class='label-form-card' for='validationCustom01'>Children(2-11 Yrs)</label>"+
                                              "<div class='quantity'>"+
                                                    "<input id='room" + rmindx + "ChildMinus' class='quantity__minus children_minus' type='button' value='-' style='color:#ffffff;'>"+
                                                    "<input  type='text' class=' quantity__input children_input' data-val='true' data-val-number='The field NoOfChildren must be a number.' data-val-required='The NoOfChildren field is required.' id='room" + rmindx + "Child' name='roomsNoOfChildren[]' type='text' value='0'>"+
                                                  " <input id='room" + rmindx + "ChildPlus' class='quantity__plus children_plus' type='button' value='+' style='color:#ffffff;'>"+
                                                "</div>"+
                                            "</div>"+
                                             "<div class='col-lg-7 col-12  font-sm-three padtop6 padlft86' style='padding-top:5px;'> <div id='divroom" + rmindx + "ChildAges1' class='row' style='margin-left: 0; display:none;width:100%;'><span id='rchild" + rmindx + "'></span> </div> </div>"+

                                        "</div>";
										
										
										

                                        
                
                var htmlObject = $.parseHTML(room);
				
                $("#divRoom" + rmid).after(htmlObject);
                roomID++;
                RoomAddBool = true;
                // alert(roomID);
            }
            //calculatePerson();
        }
         if (rmid == (maxroom)) {
            
             //$("#rmroom").addClass("hide");
			 $(this).unbind("click");
         }
         else {
             
             $("#rmroom").removeClass("hide");
         }
		 var trooms = $(".user_data").length;
		 var countroom = parseInt(trooms);

	     $("#countroom").val(countroom);
	
    });

    

    //----remove room
    
         $(document).on('click', '.custombtn1', function () {
        var rmid = 0;

        $(".user-details").find(".user_data").each(function () {
            num = parseInt(this.id.substring(7, 8));
            if (num > rmid) {
                rmid = num;
            }
        });
           
            if (rmid > 1) {
            $("#divRoom" + rmid).remove();
			
           // calculatePerson();
        }
		if (rmid == 2) {
            $("#rmroom").addClass("hide");
        }
          if (rmid == maxroom) {
            
            
            $("#rmroom").removeClass("hide");
        }
		 var trooms = $(".user_data").length;
		 var countroom = parseInt(trooms);

	     $("#countroom").val(countroom);
    });
        
         
    
	

    //---room Adult plus
    $(document).on('click', '.adult_minus', function () {
        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
       
        var roomAdultminus = $('#room' + rmid + 'Adult').val();
          if(roomAdultminus > 1 ){
            $('#room' + rmid + 'Adult').val(parseInt(roomAdultminus) - 1);
		  }
		  else{
			  alert("Atleast 1 Adult must be present");	
		  }								   
       
        //calculatePerson();
    });

    //---room Adult Minus
    $(document).on('click', '.adult_plus', function () {
        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
        
        var roomAdultplus = $('#room' + rmid + 'Adult').val();
		var roomChildplus = $('#room' + rmid + 'Child').val();								
          if(roomAdultplus < maxroom ){
			if((parseInt(roomAdultplus)+parseInt(roomChildplus))<4)
			{
               $('#room' + rmid + 'Adult').val(parseInt(roomAdultplus) + 1);
			}
			else
			{
			   alert("More than 4 person not allowed");	
			}			
		  }
       
        //calculatePerson();
    });
	 $(document).on('click', '.children_plus', function () {
        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
        var tchild = parseInt($('#room' + rmid + 'Child').val());
        var name = $('#room' + rmid + 'Child').attr('name');
        var type = name.substring(0, 4);
		 var roomAdultplus = $('#room' + rmid + 'Adult').val();
        var roomChildplus = $('#room' + rmid + 'Child').val();
         if(roomChildplus < maxroom ){
			if((parseInt(roomAdultplus)+parseInt(roomChildplus))<4)
			{ 
				
              $('#room' + rmid + 'Child').val(parseInt(roomChildplus) + 1);
			  if (tchild < 3) {
			 
            var totalchildren = parseInt(tchild) + 1;
          
            $('#room' + rmid + 'Child').val(totalchildren);

            $('#divroom' + rmid + 'ChildAges1').show();
            $('#divroom' + rmid + 'ChildAges1').css('display','inline-flex');
            if (type == 'room') {
                var rnameid = parseInt(rmid) - 1;
				 
                var cage = "<div id='divRoom" + rmid + "Child" + totalchildren + "Age' class='col-lg-4 col-4 room_col3  d-flex '><span class='buttongroup' style='font-size: 10px;'><span class='mbx'>Child " + totalchildren + " Age (Yrs) </span><div class='quantity '>"+
				"<input id='room" + rmid + "Child" + totalchildren + "AgeMinus' class='quantity__minus childAgeMinus' type='button' value='-' style='color:#ffffff;'>" +
                      "<input  type='text' class='rmiddle valid quantity__input ' value='0' data-val='true' data-val-number='The field NoOfAdults must be a number.' data-val-required='The NoOfAdults field is required.' id='room" + rmid + "Child" + totalchildren + "Age' name='roomsNoOfchildarenages[" + rnameid + "][]' >" +  
                         "<input id='room" + rmid + "Child" + totalchildren + "AgePlus' class='quantity__plus childAgePlus' type='button' value='+' style='color:#ffffff;'>"+
						 "</div>"+
						 "</span></div>";
                var htmlObject = $.parseHTML(cage);
                if (totalchildren == 1) {
                    $("#rchild" + rmid).after(htmlObject);

                }
                else {

                    var pdiv = '#divRoom' + rmid + 'Child' + tchild + 'Age';
                    $(pdiv).after(htmlObject);
                }
               
            }
           

          
        }
			   
			}
			else
			{
			   alert("More than 4 person not allowed");	
			  
			}
	 
		 }
		 
       
    });
 $(document).on('click', '.children_minus', function () {
       var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
        var totalchildren = $('#room' + rmid + 'Child').val();
        if (parseInt(totalchildren) >= 1) {
            $('#room' + rmid + 'Child').val(parseInt(totalchildren) - 1);
            $('#divRoom' + rmid + 'Child' + totalchildren + 'Age').remove();
           // calculatePerson();
            if (parseInt(totalchildren) == 1) {
                $('#divroom' + rmid + 'ChildAges1').hide();
            }
        }
        else {
            $('#' + id).addClass('disableButton');
        }
    });
    //---room Adult Minus
   $(document).on('click', '.childAgePlus', function () {
        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
        var chid = Id.substring(10, 11);
        var roomChilds = $('#room' + rmid + 'Child' + chid + 'Age').val();
        if (roomChilds < 12) {
            $('#room' + rmid + 'Child' + chid + 'Age').val(parseInt(roomChilds) + 1);
        }
      //calculatePerson();
        
    });
 $(document).on('click', '.childAgeMinus', function () {

        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
        var chid = Id.substring(10, 11);
        var roomChilds = $('#room' + rmid + 'Child' + chid + 'Age').val();
         if (roomChilds > 0) {
            $('#room' + rmid + 'Child' + chid + 'Age').val(parseInt(roomChilds) - 1);
        }
       //calculatePerson();
    });
	
   // $('.roomdone').click(function () {
        // $('.hidedone').hide();
        // $('.checkout').hide();
   // });

// $( ".roomdone" ).click(function() {
	// $('.hidedone').hide();
     // $('.checkout').hide();
  // $( ".custombtn" ).bind( "click");
// });   
	// function calculatePerson() {
    // var person = 0;
    // var trooms = $(".user_data").length;
    // for (var i = 1; i <= trooms; i++) {
	// if(rmid == 2 && i==2)
		// {
          // person = parseInt(person) + parseInt($("#room" + (i+1) + "Adult").val()) + parseInt($("#room" + (i+1) + "Child").val());
		// }
		// else if($("#room" + i + "Adult").val() == undefined)
		// {
		  // person = parseInt(person) + parseInt($("#room" + (i+1) + "Adult").val()) + parseInt($("#room" + (i+1) + "Child").val());	
		// }
		// else
		// {
		  // person = parseInt(person) + parseInt($("#room" + i + "Adult").val()) + parseInt($("#room" + i + "Child").val());	
		// }
    // }
	    // var countroom = parseInt(trooms);

    // var _selectText = parseInt(trooms) + ' Room ' + parseInt(person) + ' Person';
    // $("#select_room").val(_selectText);
	    // $("#countroom").val(countroom);

    // //var rom = _selectText.split(" ").slice(0, 2).join(" ");
    // //$("#roomsss").html(rom);
// }

   
});


$(document).ready(function () {

    (function ($) {
        $('.tab ul.tabs').addClass('active').find('> li:eq(0)').addClass('current');

        $('.tab ul.tabs li a').click(function (g) {
            var tab = $(this).closest('.tab'),
                    index = $(this).closest('li').index();

            tab.find('ul.tabs > li').removeClass('current');
            $(this).closest('li').addClass('current');

            tab.find('.tab_content').find('div.tabs_item').not('div.tabs_item:eq(' + index + ')').slideUp();
            tab.find('.tab_content').find('div.tabs_item:eq(' + index + ')').slideDown();

            g.preventDefault();
        });
    })(jQuery);

});
