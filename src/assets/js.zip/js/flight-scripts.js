/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var RoomAddBool = true;
var maxroom = 9;
var roomID = 2;
$(function(){
	 $(document).on( "click", ".custombtn", function() {

        var rmid = 0;
       
        $(".user-details").find(".user_data").each(function () {
            num = parseInt(this.id.substring(7, 8));
            if (num > rmid) {
                rmid = num;
            }
        });
        if (rmid < maxroom) {
            //Addroom(rmid + 1);
            var rmindx = parseInt(rmid) + 1;
            if (RoomAddBool == true) {
                RoomAddBool = false;
				var room = "<div id='divRoom" + rmindx + "' class='form-row user_data hidedone'>" + 
										  "<div class='col-md-2 col-3 roomdiv'>ROOM " + rmindx + "</div>" +
										  
                                           " <div class='col-md-2 col-4 padding-row-card font-sm-three'>" +
                                                "<label class='label-form-card' for='validationCustom01'>Adults(>11 Yrs)</label>" +
                                               


                                               "<div class='quantity'> " +
                                                    
													 "<input id='room" + rmindx + "AdultMinus' class='quantity__minus adult_minus' type='button' value='-' style='color:#ffffff;'>" +
                                                   " <input  type='text' class='form-control quantity__input adult_input' value='0' data-val='true' data-val-number='The field NoOfAdults must be a number.' data-val-required='The NoOfAdults field is required.' id='room" + rmindx + "Adult' name='rooms[" + rmid + "].NoOfAdults' >" +
                                                    
													"<input id='room" + rmindx + "AdultPlus' class='quantity__plus adult_plus' type='button' value='+' style='color:#ffffff;'>" +
                                               " </div>"+




                                           " </div>"+
                                            "<div class='col-md-2 col-4 padding-row-card font-sm-three ml-4' style='white-space:nowrap'>"+
                                                "<label class='label-form-card' for='validationCustom01'>Children(2-11 Yrs)</label>"+
                                              "<div class='quantity'>"+
                                                    "<input id='room" + rmindx + "AdultMinus' class='quantity__minus children_minus' type='button' value='-' style='color:#ffffff;'>"+
                                                    "<input  type='text' class='form-control quantity__input children_input' data-val='true' data-val-number='The field NoOfChildren must be a number.' data-val-required='The NoOfChildren field is required.' id='room" + rmindx + "Child' name='rooms[" + rmid + "].NoOfChildren' type='text' value='0'>"+
                                                  " <input id='room" + rmindx + "AdultPlus' class='quantity__plus children_plus' type='button' value='+' style='color:#ffffff;'>"+
                                                "</div>"+
                                            "</div>"+
                                             "<div class='col-md-3 col-12 hide checkout' id='rmroom' style='margin-left: 13px;padding-top: 38px; '>"+
											 "<button type='button' class='custombtn1'>REMOVE THIS ROOM</button>"+
											 "</div>"+

                                        "</div>";
 var htmlObject = $.parseHTML(room);
                $("#divRoom" + rmid).after(htmlObject);
                roomID++;
                RoomAddBool = true;

            }
            calculatePerson();
        }
         if (rmid == (maxroom - 1)) {
            
             $("#rmroom").addclass("hide");
         }
         else {
             
             $("#rmroom").removeclass("hide");
         }
		
    });

    

    //----remove room
    $(document).on('click', '.custombtn1', function () {
        var rmid = 0;

        $(".user-details").find(".user_data").each(function () {
            num = parseInt(this.id.substring(7, 8));
            if (num > rmid) {
                rmid = num;
            }
        });

        
            if (rmid > 1) {
            $("#divRoom" + rmid).remove();
            calculatePerson();
        }
        
         
    });
	

    //---room Adult plus
    $(document).on('click', '.adult_minus', function () {
        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
       
        var roomAdultminus = $('#room' + rmid + 'Adult').val();
         if (roomAdultminus > 0) {
            $('#room' + rmid + 'Adult').val(parseInt(roomAdultminus) - 1);
		 }
       
        calculatePerson();
    });

    //---room Adult Minus
    $(document).on('click', '.adult_plus', function () {
        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
        
        var roomAdultplus = $('#room' + rmid + 'Adult').val();
       
            $('#room' + rmid + 'Adult').val(parseInt(roomAdultplus) + 1);
        
       
        calculatePerson();
    });
	 $(document).on('click', '.children_plus', function () {
        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
        
        var roomChildplus = $('#room' + rmid + 'Child').val();
        
            $('#room' + rmid + 'Child').val(parseInt(roomChildplus) + 1);
        
       
        calculatePerson();
    });

    //---room Adult Minus
    $(document).on('click', '.children_minus', function () {
        var Id = $(this).attr('id');
        var rmid = Id.substring(4, 5);
       
        var roomChildminus = $('#room' + rmid + 'Child').val();
         if (roomChildminus > 0) {
            $('#room' + rmid + 'Child').val(parseInt(roomChildminus) - 1);
		 }
       
        calculatePerson();
    });

    $(document).on('click', '.roomdone', function () {

        $('.hidedone').hide();
		 $(document).on('focus', '#select_room', function () {
		$('.hidedone').show();
		});
    });
	
	function calculatePerson() {
    var person = 0;
    var trooms = $(".user_data").length;
    for (var i = 1; i <= trooms; i++) {
        person = parseInt(person) + parseInt($("#room" + i + "Adult").val()) + parseInt($("#room" + i + "Child").val());
    }
    var _selectText = parseInt(trooms) + ' Room ' + parseInt(person) + ' Person';
    $("#select_room").val(_selectText);
    //var rom = _selectText.split(" ").slice(0, 2).join(" ");
    //$("#roomsss").html(rom);
}

   
});
 



